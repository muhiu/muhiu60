 <?php
				
				
				
				$servername = "localhost";
				$username = "root";
				$password = "muhiu";
				$dbname = "mydb";
				// Create connection
				$conn = new mysqli($servername, $username, $password,$dbname);
				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				}
				if(isset($_POST['btnrgstr'])){
					$fname = $_POST['FName'];
					$lname = $_POST['LName'];
					$uname = $_POST['UName'];
					$pswd = $_POST['Password'];
					$emal = $_POST['Email'];
			
			
							} 
							$sql = "INSERT INTO registeration (firstname, lastname,username, password, email)
				VALUES ( '$fname' , '$lname' ,'$uname', '$pswd', '$emal' )";
				($conn->query($sql)
							?>