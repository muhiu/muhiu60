<?php
$servername = "localhost";
$username = "root";
$password = "muhiu";
$dbname = "mydb";
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if(isset($_POST['btnSubdfdfdmit'])){
	$names = $_POST['Name'];
	$emails = $_POST['Country'];
	$cnty = $_POST['Email'];
	$msg = $_POST['Hotel'];
}


// Create database
$sql = "INSERT INTO contactus (name, email, country, message)
 VALUES ( '$names' , '$emails' , '$cnty', '$msg' )";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}







$conn->close();
?>