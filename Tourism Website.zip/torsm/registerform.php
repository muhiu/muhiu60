<!DOCTYPE html>
<html lang="en">
<head>
<title>Registeration</title>
<meta charset="utf-8">
<meta name="format-detection" content="telephone=no" />
<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico" />
<link rel="stylesheet" href="booking/css/booking.css">
<link rel="stylesheet" href="booking/css/booking.css">
<link rel="stylesheet" href="css/camera.css">
<link rel="stylesheet" href="css/style.css">
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.2.1.js"></script>
<script src="js/script.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script src="js/jquery.equalheights.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="booking/js/booking.js"></script>
<script>
		$(document).ready(function(){
			$().UItoTop({ easingType: 'easeOutQuart' });
			});
		</script>
</head>

 <?php
				
				//include('db.php');
				$servername = "localhost";
				$username = "root";
				$password = "muhiu";
				$dbname = "mydb";
				// Create connection
				$conn = new mysqli($servername, $username, $password,$dbname);
				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				}
				if(isset($_POST['btnrgstr'])){
					$fname = $_POST['FName'];
					$lname = $_POST['LName'];
					$uname = $_POST['UName'];
					$pswd = $_POST['Password'];
					$emal = $_POST['Email'];
			
				
							$sql = "INSERT INTO registeration (firstname, lastname,username, password, email)
				VALUES ( '$fname' , '$lname' ,'$uname', '$pswd', '$emal' )";
				if($conn->query($sql)){
				   echo '<script language="javascript">';
echo 'alert("Registeration Successfull")';
echo '</script>';
				}
				}
							?>
                            
                            <script>
     function validate(){

        var a = document.getElementById("pwd").value;
        var b = document.getElementById("cpwd").value;
        if (a!=b) {
        alert("Passwords do no match");
        return false;
        }
    }
    </script>

<body>
<!--==============================header=================================-->
<header>
  <div class="container_12">
    <div class="grid_12">
      <div class="menu_block">
        <nav class="horizontal-nav full-width horizontalNav-notprocessed">
          <ul class="sf-menu">
            <li class="current"><a href="index.php">HOME</a></li>
            <li><a href="index-1.php">HOT TOURS</a></li>
            <li><a href="index-2.php">SPECIAL OFFERS</a></li>
            <li><a href="index-3.php">Login</a></li>
            <li><a href="index-4.php">CONTACTS</a></li>
          </ul>
        </nav>
        <div class="clear"></div>
      </div>
    </div>
    <div class="grid_12">
      <h1> <a href="index.php"> <img src="images/logo.png" alt="Your Happy Family"> </a> </h1>
    </div>
  </div>
</header>
<!--==============================Content=================================-->
<div class="content">
  <div class="container_12">
    <div class="grid_6">
      <h3>Registeration</h3>
      <form id="bookingForm" method="post">
        <div class="fl1">
          <div class="tmInput">
            <input name="FName" placeHolder="FirstName:" type="text" required>
          </div>
          <div class="tmInput">
            <input name="LName" placeHolder="LastName:" type="text" required>
          </div>
          <div class="tmInput">
            <input name="UName" placeHolder="Username:" type="text" required>
          </div>
          <div class="tmInput">
           <input name="Password" placeHolder="Password:" type="password" id="pwd" required>
          </div>
          <div class="tmInput">
            <input name="CPassword" placeHolder="ConfirmPassword:" type="password"  id="cpwd" required>
          </div>
          <div class="tmInput">
            <input name="Email" placeHolder="Email" type="email" onClick="return validate();" required>
          </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div class="fl1">
          <input type="submit" name="btnrgstr" value="Register">
        </div>
      </form>
    </div>
   
  </div>
</div>
<!--==============================footer=================================-->
<footer>
  <div class="container_12">
    <div class="grid_12">
      <div class="socials"> <a href="#" class="fa fa-facebook"></a> <a href="#" class="fa fa-twitter"></a> <a href="#" class="fa fa-google-plus"></a> </div>
      <div class="copy"> Muhiu Special's (c) 2015 | <a href="#">Privacy Policy</a> | www.Muhiu60.com </div>
    </div>
  </div>
</footer>
<script>
		$(function (){
			$('#bookingForm').bookingForm({
				ownerEmail: '#'
			});
		})
		</script>
</body>
</html>
