<!DOCTYPE html>
<html lang="en">
<head>
<title>Submit Form</title>
<meta charset="utf-8">
<meta name="format-detection" content="telephone=no" />
<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico" />
<link rel="stylesheet" href="booking/css/booking.css">
<link rel="stylesheet" href="css/camera.css">
<link rel="stylesheet" href="css/style.css">
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.2.1.js"></script>
<script src="js/script.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script src="js/jquery.equalheights.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="booking/js/booking.js"></script>
<script src="js/camera.js"></script>
<script src="js/owl.carousel.js"></script>
<!--[if (gt IE 9)|!(IE)]><!-->
<script src="js/jquery.mobile.customized.min.js"></script>
<!--<![endif]-->
<script>
		$(document).ready(function(){
			$().UItoTop({ easingType: 'easeOutQuart' });
			});
		</script>
</head>
<?php 
		session_start();
		if(!isset($_SESSION['username']))
		{
		 header('Location:index-3.php');
		}
		
		?>

<?php 
				$servername = "localhost";
				$username = "root";
				$password = "muhiu";
				$dbname = "mydb";
				// Create connection
				$conn = new mysqli($servername, $username, $password,$dbname);
				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				}
				$name=$_SESSION['username'];
				if(isset($_POST['btnSubmit'])){
				
					$names = $_POST['Name'];
					$emails = $_POST['Country'];
					$cnty = $_POST['Email'];
					$htl = $_POST['Hotel'];
					$cin = $_POST['Check-in'];
					$cout = $_POST['Check-out'];
					$cmft = $_POST['Comfort'];
					$adlt = $_POST['Adults'];
					$cld = $_POST['Children'];
					$roms = $_POST['Rooms'];
					$msg = $_POST['Message'];
				
				// Create database
				$sql = "INSERT INTO bookingform (name,email,country,hotel,cin,cout,comfort,adult,children,room,message) VALUES ('$names','$emails','$cnty','$htl','$cin','$cout','$cmft','$adlt','$cld','$roms','$msg')";
				if ($conn->query($sql) === TRUE) {
					echo "data inserted";
				} else {
					echo "Error insertion: " . $conn->error;
					
				}
				header('Location:showdata.php');
}
				$conn->close();
				?>

<body>
<!--==============================header=================================-->
<header>
  <div class="container_12">
    <div class="grid_12">
      <div class="menu_block">
        <nav class="horizontal-nav full-width horizontalNav-notprocessed">
          <ul class="sf-menu">
            <li class="current"><a href="index.php">HOME</a></li>
            <li><a href="index-1.php">HOT TOURS</a></li>
            <li><a href="index-2.php">SPECIAL OFFERS</a></li>
            <li><a href="index-3.php">Login</a></li>
            <li><a href="index-4.php">CONTACTS</a></li>
          </ul>
        </nav>
        <div class="clear"></div>
      </div>
    </div>
    <div class="grid_12">
      <h1> <a href="index.php"> <img src="images/logo.png" alt="Your Happy Family"> </a> </h1>
    </div>
  </div>
</header>
<!--==============================Content=================================-->
<div class="content">
  <div class="container_12">
    <div class="grid_6">
      <h2 style="margin-top:20px; font-size:22px; text-align:right; margin-right:-550px; color:#000000;"> Welcome <?php echo $name ; ?> </h2>  
 <div class="tmInput"><div class="fll"><div id="book"><a href="logout2.php">     <input type="submit" name="logout" value="Logout" style="text-align:right; margin-left:950px; width:70px"></a> </div></div></div>
      <h3>Booking Form</h3>
      <form id="bookingForm" method="post" action="">
        <div class="fl1">
          <div class="tmInput">
            <input name="Name" placeHolder="Name:" type="text" required>
          </div>
          <div class="tmInput">
            <input name="Country" placeHolder="Country:" type="text" required>
          </div>
        </div>
        <div class="fl1">
          <div class="tmInput">
            <input name="Email" placeHolder="Email:" type="email" required>
          </div>
          <div class="tmInput mr0">
            <input name="Hotel" placeHolder="Hotel:" type="text" required>
          </div>
        </div>
        <div class="clear"></div>
        <strong>Check-in</strong>
        <label class="tmDatepicker">
        <input type="text" name="Check-in" placeHolder='10/05/2014' required>
        </label>
        <div class="clear"></div>
        <strong>Check-out</strong>
        <label class="tmDatepicker">
        <input type="text" name="Check-out" placeHolder='20/05/2014' required>
        </label>
        <div class="clear"></div>
        <div class="tmRadio">
          <p>Comfort</p>
          <input name="Comfort" type="radio" id="tmRadio0" value="Comfort", groups=[RadioGroup])' checked/>
          <span>Cheap</span>
          <input name="Comfort" type="radio" id="tmRadio1" value="Cheap" data-constraints='@RadioGroupChecked(name="Comfort", groups=[RadioGroup])' />
          <span>Standart</span>
          <input name="Comfort" type="radio" id="tmRadio2" value="Standard" data-constraints='@RadioGroupChecked(name="Comfort", groups=[RadioGroup])' />
          <span>Lux</span> </div>
        <div class="clear"></div>
        <div class="fl1 fl2"> <em>Adults</em>
          <select name="Adults" class="tmSelect auto" data-class="tmSelect tmSelect2" data-constraints="">
            <option>1</option>
            <option>1</option>
            <option>2</option>
            <option>3</option>
          </select>
          <div class="clear"></div>
          <em>Rooms</em>
          <select name="Rooms" class="tmSelect auto" data-class="tmSelect tmSelect2" >
            <option>1</option>
            <option>1</option>
            <option>2</option>
            <option>3</option>
          </select>
        </div>
        <div class="fl1 fl2"> <em>Children</em>
          <select name="Children" class="tmSelect auto" data-class="tmSelect tmSelect2" data-constraints="">
            <option>0</option>
            <option>0</option>
            <option>1</option>
            <option>2</option>
          </select>
        </div>
        <div class="clear"></div>
        <div class="tmTextarea">
          <textarea name="Message" placeHolder="Message"></textarea>
        </div>
        <input type="submit" name="btnSubmit" value="Submit!!" style="width:120px; margin-left:150px">
      </form>
    </div>
  </div>
</div>




<!--==============================footer=================================-->
<footer>
  <div class="container_12">
    <div class="grid_12">
      <div class="socials"> <a href="#" class="fa fa-facebook"></a> <a href="#" class="fa fa-twitter"></a> <a href="#" class="fa fa-google-plus"></a> </div>
      <div class="copy"> Muhiu Special's (c) 2015 | <a href="#">Privacy Policy</a> | www.Muhiu60.com </div>
    </div>
  </div>
</footer>
<script>
		$(function (){
			$('#bookingForm').bookingForm({
				ownerEmail: '#'
			});
		})
		</script>
</body>
</html>
