<!DOCTYPE html>
<html lang="en">
<head>
<title>Contacts</title>
<meta charset="utf-8">
<meta name="format-detection" content="telephone=no" />
<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico" />
<link rel="stylesheet" href="css/form.css">
<link rel="stylesheet" href="css/style.css">
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.2.1.js"></script>
<script src="js/script.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script src="js/jquery.equalheights.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script>
		$(document).ready(function(){
			$().UItoTop({ easingType: 'easeOutQuart' });
			});
		</script>
</head>
<?php 
					  $servername = "localhost";
						$username = "root";
						$password = "muhiu";
						$dbname = "mydb";
						// Create connection
						$conn = new mysqli($servername, $username, $password,$dbname);
						// Check connection
						if ($conn->connect_error) {
							die("Connection failed: " . $conn->connect_error);
						}
						if(isset($_POST['btnSubmit'])){
							$names = $_POST['nam'];
							$emails = $_POST['emal'];
							$cnty = $_POST['cntry'];
							$msg = $_POST['mesage'];
							// Create database
					$sql = " INSERT into contactus set
						     name = '$names',
							 email ='$emails',
							 country='$cnty',
							 message ='$msg'";
						if(mysqli_query($conn,$sql))
					{			 
					echo "";		 						
					}	
						}						
					else 					
					{
					echo "there is an error";
					}							
						?>
<body>
<!--==============================header=================================-->
<header>
  <div class="container_12">
    <div class="grid_12">
      <div class="menu_block">
        <nav class="horizontal-nav full-width horizontalNav-notprocessed">
          <ul class="sf-menu">
            <li class="current"><a href="index.php">HOME</a></li>
            <li><a href="index-1.php">HOT TOURS</a></li>
            <li><a href="index-2.php">SPECIAL OFFERS</a></li>
            <li><a href="index-3.php">Login</a></li>
            <li><a href="index-4.php">CONTACTS</a></li>
          </ul>
        </nav>
        <div class="clear"></div>
      </div>
    </div>
    <div class="grid_12">
      <h1> <a href="index.php"> <img src="images/logo.png" alt="Your Happy Family"> </a> </h1>
    </div>
  </div>
</header>
<!--==============================Content=================================-->
<div class="content">
  <div class="container_12">
    <div class="grid_5">
      <h3>CONTACT INFO</h3>
      <div class="map">
        <p><span class="blog">You can find place here or you can can cantact us on the following address </span></p>
        <div class="clear"></div>
        <figure class="">
          <iframe src="http://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Brooklyn,+New+York,+NY,+United+States&amp;aq=0&amp;sll=37.0625,-95.677068&amp;sspn=61.282355,146.513672&amp;ie=UTF8&amp;hq=&amp;hnear=Brooklyn,+Kings,+New+York&amp;ll=40.649974,-73.950005&amp;spn=0.01628,0.025663&amp;z=14&amp;iwloc=A&amp;output=embed"></iframe>
        </figure>
        <address>
        <dl>
          <dt>Muhiu 60 <br>
            Bahawalnagar Road,<br>
            Haroonabad. </dt>
          <dd><span>Freephone:</span>+923333333333</dd>
          <dd><span>Telephone:</span>+921333333333</dd>
          <dd><span>FAX:</span>+923222222222</dd>
          <dd>E-mail: <a href="#" class="col1">mahiu60@gmail.com</a></dd>
        </dl>
        </address>
      </div>
    </div>
    <div class="grid_6 prefix_1">
      <h3>GET IN TOUCH</h3>
      <form id="form" method="post" action="">
        <div class="success_wrapper">
          <div class="success-message">Contact form submitted</div>
        </div>
        <label class="name">
        <input type="text" placeholder="Name:" name="nam"  required />
        </label>
        <label class="email">
        <input type="email" placeholder="Email:" name="emal" required />
        </label>
        <label class="country">
        <input type="text" placeholder="Country:" name="cntry" required/>
        </label>
        <label class="message">
        <textarea placeholder="Message:" name="mesage" maxlength="500" > </textarea>
        </label>
        <div>
          <div class="clear"></div>
          <div  class="btns">
            <input type="submit" name="btnSubmit" value="Submit!!">
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<!--==============================footer=================================-->
<footer>
  <div class="container_12">
    <div class="grid_12">
      <div class="socials"> <a href="#" class="fa fa-facebook"></a> <a href="#" class="fa fa-twitter"></a> <a href="#" class="fa fa-google-plus"></a> </div>
      <div class="copy"> Muhiu Special's (c) 2015 | <a href="#">Privacy Policy</a> | www.Muhiu60.com </div>
    </div>
  </div>
</footer>
<script>
		$(function (){
			$('#bookingForm').bookingForm({
				ownerEmail: '#'
			});
		})
		</script>
</body>
</html>
