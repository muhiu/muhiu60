<?php 
  session_start();
$servername = "localhost";
				$username = "root";
				$password = "muhiu";
				$dbname = "mydb";
				// Create connection
				$conn = new mysqli($servername, $username, $password,$dbname);
				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				} 
  $name= $_POST['uname'];
  $password= $_POST['password'];
  
				
 
 $sql= "select * from registeration where  username ='$name' and password ='$password'";
  
  $data=mysqli_query($conn,$sql);
  $rows =mysqli_num_rows($data);
  $result=mysqli_fetch_array($data);
  
  if($rows>0)
  {
  
  $_SESSION['username']=$result['username'];
  $_SESSION['userid']=$result['id'];
  
  header('Location:submit.php');
  
  
  }


else {
      
header('Location:index-3.php?msg=1');

  }
   
    

  

?>
