<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>
<center>
  <div style="border:thick #000000 1px ;">
    <h3 style="font-size:36px"> Admin Panel </h3>
    <form method="post" action="adminshow.php">
      <table align="center" border="1" style="border-collapse:collapse">
        <tr>
          <td> Username:</td>
          <td><input type="text" name="username" required />
          </td>
        </tr>
        <tr>
          <td> Password:</td>
          <td>
          <input type="password" name="password" required />
          </td>
        </tr>
        <tr>
          <td></td>
          <td ><input type="submit" name="submit" value="Login" style=" width:80px; height:30px"/>
          </td>
        </tr>
      </table>
    </form>
  </div>
</center>
</body>
</html>
