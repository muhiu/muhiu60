<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin Panel</title>
</head>
<style>
input {
text-decoration:none;
}

</style>
<body>
<center>
<h1> Admin Panel </h1>
<h5 style="font-size:18px">
Choose which data you want to show:
</h5>
<table>
<tr> <td>
<a href="contactshowadmin.php"><input type="submit" name="sbmt" value="Contact US" /> </a></td>
<td>
<a href="bookingformdetail.php"><input type="submit" name="sbmt" value="Booking Form" /></a> </td>
</tr>
</table>
<button> Logout </button>

</center>
</body>
</html>
