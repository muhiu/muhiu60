<?php 
	  
	            session_start();
				$servername = "localhost";
				$username = "root";
				$password = "muhiu";
				$dbname = "mydb";
				// Create connection
				$conn = new mysqli($servername, $username, $password,$dbname);
				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				
				
				                          }
					$id =$_REQUEST['userid'];
					$name = $_REQUEST['name'];
					$country =$_REQUEST['cnty'];
										  
	              $sql="update bookingform set name = '$name' , cnty = '$country' where userid ='$id' ";
		         if(!mysqli_query($conn,$sql)
				 {
				 	echo "<script language = 'javascript' msg: Successfully Inserted>"; 
				 }
				// print_r($data);
				
				 
 ?>