
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin Panel</title>
<meta charset="utf-8">
<meta name="format-detection" content="telephone=no" />
<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico" />
<link rel="stylesheet" href="booking/css/booking.css">
<link rel="stylesheet" href="booking/css/booking.css">
<link rel="stylesheet" href="css/camera.css">
<link rel="stylesheet" href="css/style.css">
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.2.1.js"></script>
<script src="js/script.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script src="js/jquery.equalheights.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="booking/js/booking.js"></script>

		
		
		<script>
		$(document).ready(function(){
			$().UItoTop({ easingType: 'easeOutQuart' });
			});
		</script>
		<?php 
		session_start();
		if(!isset($_SESSION['username']))
		{
		 header('Location:admins.php');
		}
		
		?>
	</head>
    
 
	<body>
<!--==============================header=================================-->
		<header>
			<div class="container_12">
				<div class="grid_12">
					<div class="menu_block">
						<nav class="horizontal-nav full-width horizontalNav-notprocessed">
							<ul class="sf-menu">
							<li class="current"><a href="index.php">HOME</a></li>
								<li><a href="index-1.php">HOT TOURS</a></li>
								<li><a href="index-2.php">SPECIAL OFFERS</a></li>
								<li><a href="index-3.php">Login</a></li>
								<li><a href="index-4.php">CONTACTS</a></li>
							</ul>
					  </nav>
						<div class="clear"></div>
					</div>
				</div>
				<div class="grid_12">
					<h1>
						<a href="index.php">
							<img src="images/logo.png" alt="Your Happy Family">						</a>					</h1>
			  </div>
			</div>
		</header>
<!--==============================Content=================================-->
	<div class="content">
			<div class="container_12">

	<div class="grid_6">
			
            						<center>
<h1 style="font-size:50px; margin-top:20px; margin-left:-100px"> Admin Panel </h1>
<h5 style="font-size:18px; margin-left:-110px">
Choose which data you want to show:
</h5>
<div id="bookingForm">
<div class="fl1">
<div class="tmInput">
<table>
<tr> <td>
<a href="contactshowadmin.php"><input type="submit" name="sbmt" value="Contact US" style="margin-left:-10px" /> </a></td>
<td>
<a href="bookingformdetail.php"><input type="submit" name="sbmt" value="Booking Form" /></a> &nbsp; </td>
<td>
<a href="registerdetail.php"><input type="submit" name="sbmt" value="Registeration Form" style="margin-left:-10px" /></a>&nbsp; </td>
</tr>
</table>
<a href="logout.php"><input type="submit" value="Logout" name="login" style="width:70px; margin-left:150px"></a> </div>
</div></div>
</center>
            
				</div>
	
	<div id="imds" style="float:right; margin-top:-180px;">
	
	<img src="images/page4_img1.jpg" alt="">
	
	</div>
	
	
	</div>
	</div>	
    
    
    

		
		
<!--==============================footer=================================-->
		<footer>
			<div class="container_12">
				<div class="grid_12">
					<div class="socials">
						<a href="#" class="fa fa-facebook"></a>
						<a href="#" class="fa fa-twitter"></a>
						<a href="#" class="fa fa-google-plus"></a>
					</div>
					<div class="copy">
						Muhiu Special's (c) 2015 | <a href="#">Privacy Policy</a> | www.Muhiu60.com
					</div>
				</div>
			</div>
		</footer>
		<script>
		$(function (){
			$('#bookingForm').bookingForm({
				ownerEmail: '#'
			});
		})
		</script>
	</body>
</html>