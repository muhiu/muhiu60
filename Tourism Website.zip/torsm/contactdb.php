<?php

$servername = "localhost";
$username = "root";
$password = "muhiu";
$dbname = "mydb";
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['btnSudbmit'])){
	$names = $_POST['nam'];
	$emails = $_POST['emal'];
	$cnty = $_POST['cntry'];
	$msg = $_POST['mesage'];
}


// Create database
$sql = "INSERT INTO contactus (name, email, country, message)
VALUES ( '$names' , '$emails' , '$cnty', '$msg' )";
$conn->query($sql)
?>




							