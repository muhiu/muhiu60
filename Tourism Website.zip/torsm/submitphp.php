 <?php 
		//include("submit.php");
				$servername = "localhost";
				$username = "root";
				$password = "muhiu";
				$dbname = "mydb";
				// Create connection
				$conn = new mysqli($servername, $username, $password,$dbname);
				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				}
				if(isset($_POST['btnSubmit'])){
					$names = $_POST['Name'];
					$emails = $_POST['Country'];
					$cnty = $_POST['Email'];
					$htl = $_POST['Hotel'];
					$cin = $_POST['Check-in'];
					$cout = $_POST['Check-out'];
					$cmft = $_POST['Comfort'];
					$adlt = $_POST['Adults'];
					$cld = $_POST['Children'];
					$roms = $_POST['rooms'];
					$msg = $_POST['Message'];
				}
				// Create database
				$sql = "INSERT INTO bookingform (name, email, country, hotel, cin, cout, comfort, adult, children, room, message)
				VALUES ( '$names' , '$emails' , '$cnty', '$htl','$cin' , '$cout' , '$cmft', '$adlt', '$cld' , '$roms', '$msg' )";
				if ($conn->query($sql) === TRUE) {
					echo "";
				} else {
					echo "Error insertion: " . $conn->error;
				}
				
				
				
				
				$conn->close();
				?>
