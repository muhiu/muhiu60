
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ubaid.procare
 */
public final class ImagePanel extends JPanel{
    private BufferedImage image;
    String str;

    public ImagePanel() {      
    }
    public void removeImage(){

          this.image = null;
          this.repaint();
    }
    public void loadImage(String filename) {
        try {
            this.image = ImageIO.read(new File(filename));
        } catch (IOException ex) {
            Logger.getLogger(ImagePanel.class.getName()).log(Level.SEVERE, null, ex);
        }
          this.repaint();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
            if (image != null) {
            int scaledWidth = (int)((image.getWidth() * getHeight()/image.getHeight()));
            if (scaledWidth < getWidth()) {
                int leftOffset = getWidth() / 2 - scaledWidth / 2;
                int rightOffset = getWidth() / 2 + scaledWidth / 2;
                g.drawImage(image, leftOffset, 0, rightOffset, getHeight(), 0, 0, image.getWidth(), image.getHeight(), null);
            }
            else {
                int scaledHeight = (image.getHeight() * getWidth()) / image.getWidth();
                int topOffset = getHeight() / 2 - scaledHeight / 2;
                int bottomOffset = getHeight() / 2 + scaledHeight / 2;
                g.drawImage(image, 0, topOffset, getWidth(), bottomOffset, 0, 0, image.getWidth(), image.getHeight(), null);
            }
        }
    }
}
