﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SIS
{
    public partial class Search_Record : Form
    {
        public Search_Record()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = radioButton1.Checked;
           // button1.Enabled = radioButton1.Checked;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Enabled = radioButton2.Checked;
           //button2.Enabled = radioButton1.Checked;
        }

        private void Search_Record_Load(object sender, EventArgs e)
        {
            radioButton1.Select();
            textBox1.Enabled = radioButton1.Checked;
            textBox2.Enabled = radioButton2.Checked;
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            string _cstring = "Data Source=MUHIUDIN; Initial Catalog=student; Integrated Security=True";
            SqlConnection cn = new SqlConnection(_cstring);
            string _query = "select registerationno,studentname,fathername,class,age,guardiandname,phoneno from addrecord where registerationno = '" + textBox1.Text + "'";
            cn.Open();



            

            SqlCommand cmd = new SqlCommand(_query, cn);


            cmd.CommandType = CommandType.Text;

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataSet ds = new DataSet();

            da.Fill(ds, "ss");

            dataGridView1.DataSource = ds.Tables["ss"]; ;

            cmd.Dispose();
            cn.Close();
            cn.Dispose();








        }

        private void button2_Click(object sender, EventArgs e)
        {


            string cstring = "Data Source=MUHIUDIN; Initial Catalog=student; Integrated Security=True";
            SqlConnection cnn = new SqlConnection(cstring);
            string query = "select registerationno,studentname,fathername,class,age,guardiandname,phoneno from addrecord where studentname = '" + textBox2.Text + "'";
            cnn.Open();





            SqlCommand cmds = new SqlCommand(query, cnn);


            cmds.CommandType = CommandType.Text;

            SqlDataAdapter das = new SqlDataAdapter(cmds);

            DataSet dss = new DataSet();

            das.Fill(dss, "ss");

            dataGridView1.DataSource = dss.Tables["ss"]; ;

            cmds.Dispose();
            cnn.Close();
            cnn.Dispose();




        }
    }
}
