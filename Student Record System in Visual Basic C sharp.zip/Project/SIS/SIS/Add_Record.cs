﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
namespace SIS
{
    public partial class Add_Record : Form
    {
        public Add_Record()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "JPEG Files (*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif|All Files(*.*)|*.*";
            dlg.Title = "Select Student Picture";
            if (dlg.ShowDialog() == DialogResult.OK)
            {

                string picloc = dlg.FileName.ToString();
                pictureBox1.ImageLocation = picloc;
                textpath.Text = picloc;
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        
    
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string gender = string.Empty;
            if (radioButton1.Checked)
            {
                gender = "Recommended";
            }
            else if (radioButton2.Checked)
            {
                gender = "Not Recommended";
            }

            byte[] imagBT = null;
           FileStream fs = new FileStream(this.textpath.Text, FileMode.Open, FileAccess.Read);
           BinaryReader br = new BinaryReader(fs);
           imagBT = br.ReadBytes((int)fs.Length);
            
            string _cstring = "Data Source=MUHIUDIN; Initial Catalog=student; Integrated Security=True";
            SqlConnection cn = new SqlConnection(_cstring);
            //string cm = comboBox1.SelectedItem.ToString();
            string _query = "INSERT INTO addrecord (studentname, fathername, age, gender, class, lastattendedclass, address, guardiandname, relationwithstudent, occupation, officeaddress, mobileno, phoneno, addressguardian, admission, section, registerationno,admissiondate, image) VALUES ('" + textBox1.Text + "','" + textBox4.Text + "','" + textBox2.Text + "','" + comboBox1.SelectedItem.ToString() + "','" + textBox3.Text + "','" + textBox5.Text + "','" + textBox7.Text + "','" + textBox6.Text + "','" + textBox10.Text + "','" + textBox8.Text + "','" + textBox11.Text + "','" + textBox9.Text + "','" + textBox12.Text + "','" + textBox13.Text + "','" + gender + "','" + textBox14.Text + "','" + textBox15.Text + "','" + dateTimePicker1.Value + "',@IMG);";

           // _query = string.Format(_query, textBox1.Text, textBox4.Text, textBox2.Text, comboBox1.SelectedItem.ToString(), textBox3.Text, textBox5.Text, textBox7.Text, textBox6.Text, textBox10.Text, textBox8.Text, textBox11.Text, textBox9.Text, textBox12.Text, textBox13.Text, gender, textBox14.Text, textBox15.Text, dateTimePicker1.Value);


            
                cn.Open();

                SqlCommand _cmd = new SqlCommand(_query, cn);
                _cmd.Parameters.Add(new SqlParameter("@IMG", imagBT));


                _cmd.ExecuteNonQuery();
                MessageBox.Show("Record Saved!");
            

            _cmd.Dispose();
            cn.Close();
            cn.Dispose();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }
    }
}
