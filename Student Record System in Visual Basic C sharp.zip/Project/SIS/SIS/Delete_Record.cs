﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SIS
{
    public partial class Delete_Record : Form
    {
        public Delete_Record()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string _cstrings = "Data Source=MUHIUDIN; Initial Catalog=student; Integrated Security=True";
            SqlConnection cnn = new SqlConnection(_cstrings);

            string query = "DELETE FROM addrecord WHERE registerationno = '" + textBox1.Text + "'";
            cnn.Open();
            SqlCommand cmd = new SqlCommand(query, cnn);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Saved!");


            cmd.Dispose();
            cnn.Close();
            cnn.Dispose();


            //MessageBox.Show("Are you Sure?", MessageBoxButtons.OK);
           

            DialogResult dialogResult = MessageBox.Show("Are you Sure?", "Confirmation", MessageBoxButtons.YesNo);
           
            if (dialogResult == DialogResult.Yes)
            {
                MessageBox.Show("Record Deleted Successfully!");
            }
            else if (dialogResult == DialogResult.No)
            {

            }
            else
            {
                MessageBox.Show("Error Occured!!Try Again!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string _cstring = "Data Source=MUHIUDIN; Initial Catalog=student; Integrated Security=True";
            SqlConnection cn = new SqlConnection(_cstring);
            string _query = "select * from addrecord where registerationno = '" + textBox1.Text + "'";
            cn.Open();

            SqlCommand _cmd = new SqlCommand(_query, cn);

            SqlDataReader sdr = _cmd.ExecuteReader();

            while (sdr.Read())
            {
                textBox6.Text = sdr["studentname"].ToString();
                textBox4.Text = sdr["fathername"].ToString();
                textBox2.Text = sdr["age"].ToString();
                textBox3.Text = sdr["gender"].ToString();
                textBox5.Text = sdr["class"].ToString();
                textBox7.Text = sdr["lastattendedclass"].ToString();
                textBox15.Text = sdr["address"].ToString();
                textBox8.Text = sdr["guardiandname"].ToString();
                textBox9.Text = sdr["relationwithstudent"].ToString();
                textBox10.Text = sdr["occupation"].ToString();
                textBox11.Text = sdr["officeaddress"].ToString();
                textBox12.Text = sdr["mobileno"].ToString();
                textBox13.Text = sdr["phoneno"].ToString();
                textBox14.Text = sdr["addressguardian"].ToString();
            }

            _cmd.Dispose();
            cn.Close();
            cn.Dispose();


        }
    }
}
